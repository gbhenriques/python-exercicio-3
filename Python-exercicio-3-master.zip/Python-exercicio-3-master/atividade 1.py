#Faça um programa que dado o valor da temperatura em graus FARENHEIT,
#calcular e escrever o valor da temperatura em graus CELSIUS.



Fahrenheit = int(input("Temperatura em fahrenheit: "))

Celsius = (Fahrenheit - 32) * 5/9

print (Celsius)

